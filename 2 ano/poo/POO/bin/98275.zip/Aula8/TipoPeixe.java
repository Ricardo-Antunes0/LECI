package Aula8;

public enum TipoPeixe {
    CONGELADO,
    FRESCO
}
