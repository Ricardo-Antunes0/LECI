public class Box
{
   private double height;
   private double width;
   private double depth;

   /**
      Constructs a box with a given side length.
      @param sideLength the length of each side
   */   
   public Box(double h, double w, double d)
   {
      this.height = h;
      this.width = w;
      this.depth = d;
   }

   /**
      Gets the volume of this box.
      @return the volume
   */
   public double volume()
   {
    double vol = this.height*this.width*this.depth;  
    return vol;  
   }
   /**
      Gets the surface area of this box.
      @return the surface area
   */
   public double surfaceArea()
   {
      double AreaT, areaL, areaVertical, areaHorizontal;
      
      areaL = this.height * this.width; 
      areaVertical = this.height * this.depth;
      areaHorizontal = this.width* this.depth;
      AreaT = 2*areaL + 2*areaVertical + 2*areaHorizontal;
      return AreaT;
   }
}